import json,re,csv,html,collections,hashlib,zipfile,difflib
from pathlib import Path
from bs4 import BeautifulSoup
from kiwipiepy import Kiwi
from wordcloud import WordCloud
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import koreanize_matplotlib
p=Path(__file__).parent;x=json.loads((p/'raw.json').read_text());s=BeautifulSoup((p/'baseline.html').read_text(),'html.parser')
old={}
for d in s.select('details.item'):
 a=d.summary.get_text().split(' · ');pr=d.select('pre');old[a[0]]={'date':a[1],'title':a[2],'body':pr[0].get_text(),'answer':pr[1].get_text() if len(pr)>1 else '', 'related':a[-1]=='관련'}
oldrows={}
for tr in s.select('table')[-1].select('tr')[1:]:
 c=[z.get_text(' ',strip=True) for z in tr.select('td')]
 if c:oldrows[c[0]]=c
assert len(oldrows)==94
records=[];di=iter(x['docs'])
for r in x['rows']:
 c=r['cells'];n=re.search(r'\((\d{4}-\d+)\)',c[0]).group(1);a={'number':n,'date':c[2],'title':r['title'],'department':c[3],'status':c[4],'public':'비공개' not in r['title'],'body':'','answer':'','answer_date':''}
 if a['public']:
  d=next(di);assert d['title']==r['title'],(n,d['title'],r['title'])
  txt=d['text'];a['title']=txt.split('\n')[0];a['body']=txt.split('민원내용\t',1)[1].split('\n답변\n',1)[0].strip()
  if '답변 내용\t' in txt:a['answer']=txt.split('답변 내용\t',1)[1].split('\n하트',1)[0].strip()
  m=re.search(r'답변일\t(\d{4}-\d\d-\d\d)',txt);a['answer_date']=m.group(1) if m else ''
 a['related']=a['public'] and ((n in old and old[n]['related']) or ('3구역' in a['title']+a['body'] or '159번지' in a['body'] or '159지번' in a['body']) and a['department']=='균형개발과')
 a['change']='신규 검색 노출' if n not in oldrows else '기존'
 if n in old and a['answer'] and old[n]['answer']=='수집 화면에 답변 없음':a['change']='답변 추가'
 records.append(a)
assert len(records)==113 and sum(r['public'] for r in records)==92
rel=[r for r in records if r['related']];new=[r for r in rel if r['number'] not in oldrows];private=[r for r in records if not r['public']]
missing=sorted(set(oldrows)-{r['number'] for r in records});newall=[r for r in records if r['number'] not in oldrows]
print('COUNTS',len(rel),len(new),len(newall),len(private),missing)
(p/'records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
def csvwrite(name,rr,fields):
 with (p/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rr)
csvwrite('all_petitions.csv',records,list(records[0]));csvwrite('changes.csv',[r for r in records if r['change']!='기존'],['number','date','title','change','status','answer_date'])
kiwi=Kiwi();stop=set('광명 광명시 광명동 구역 번지 공공 재개발 공공재개발 주민 지역 우리 저희 요청 부탁 생각 경우 문제 부분 내용 사항 관련 때문 정도 이번 일원 시장 감사 답변 민원 사람 바람 제발 사업'.split())
def tokens(t):return [z.form for z in kiwi.tokenize(t) if z.tag in ('NNG','NNP') and len(z.form)>1 and z.form not in stop]
def freq(rr,key='body'):
 tf=collections.Counter();df=collections.Counter()
 for r in rr:
  tt=tokens(r[key]);tf.update(tt);df.update(set(tt))
 return tf,df
TF,DF=freq(rel);NT,ND=freq(new);AT,AD=freq(rel,'answer');OT,OD=freq([r for r in old.values() if r['related']])
csvwrite('tokens.csv',[{'token':t,'TF':TF[t],'DF':DF[t],'DF_percent':round(100*DF[t]/len(rel),2),'new_DF':ND[t],'baseline_DF':OD[t]} for t in DF],['token','TF','DF','DF_percent','new_DF','baseline_DF'])
font='/root/.local/lib/python3.12/site-packages/koreanize_matplotlib/fonts/NanumGothic.ttf'
for name,f in [('wordcloud_df',DF),('wordcloud_tf',TF),('wordcloud_new',ND),('wordcloud_answer',AD)]:
 WordCloud(font_path=font,width=1400,height=700,background_color='white',colormap='viridis',random_state=159,max_words=90).generate_from_frequencies(f).to_file(str(p/(name+'.png')))
fig,ax=plt.subplots(figsize=(11,5));top=DF.most_common(18)[::-1];ax.barh([a for a,b in top],[b for a,b in top]);ax.set_xlabel('해당 명사를 사용한 관련 공개 민원 수 (DF)');fig.tight_layout();fig.savefig(p/'token_df.png',dpi=140);plt.close(fig)
months=collections.Counter(r['date'][:7] for r in rel);fig,ax=plt.subplots(figsize=(10,4));ax.bar(sorted(months),[months[m] for m in sorted(months)]);ax.set_ylabel('관련 공개 민원 수');fig.tight_layout();fig.savefig(p/'monthly.png',dpi=140);plt.close(fig)
themes={'상가 언급':r'상가','포함·편입·합류':r'포함|편입|합류','제척 언급':r'제척|재척','형평·차별·공정':r'형평|차별|공정','안전·화재·소방':r'안전|화재|소방','침수·누수':r'침수|누수','동의·70% 주장':r'동의|70\s*%','기반시설·도로':r'기반시설|도로','존치 언급':r'존치'}
counts=[{'theme':k,'current':sum(bool(re.search(v,r['body'])) for r in rel),'new':sum(bool(re.search(v,r['body'])) for r in new)} for k,v in themes.items()];csvwrite('themes.csv',counts,['theme','current','new'])
pairs=[]
for i,a in enumerate(rel):
 for b in rel[i+1:]:
  aa=re.sub(r'\s+','',a['body']);bb=re.sub(r'\s+','',b['body'])
  if min(len(aa),len(bb))/max(len(aa),len(bb),1)<.8:continue
  score=difflib.SequenceMatcher(None,aa,bb,autojunk=False).ratio()
  if score>=.85:pairs.append({'a':a['number'],'b':b['number'],'similarity':round(score,4)})
csvwrite('similarity.csv',pairs,['a','b','similarity'])
from datetime import date
lags=[(date.fromisoformat(r['answer_date'])-date.fromisoformat(r['date'])).days for r in rel if r['answer_date']]
summary={'collected':'2026-11-08','search':113,'public':92,'private':len(private),'related_public':len(rel),'unrelated_public':92-len(rel),'new_search':len(newall),'missing_baseline':missing,'new_related':len(new),'answers_added':sum(r['change']=='답변 추가' for r in records),'monthly':months,'similar_pairs':len(pairs),'median_answer_days':__import__('statistics').median(lags),'baseline_sha256':hashlib.sha256((p/'baseline.html').read_bytes()).hexdigest()};(p/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(summary)
e=html.escape
def table(headers,rows):return '<div class=scroll><table><tr>'+''.join('<th>'+e(str(v))+'</th>' for v in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+e(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</table></div>'
body=f'''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>광명3구역 159 민원 분석 · 2026-11-08</title><style>body{{font:16px/1.7 sans-serif;max-width:1150px;margin:auto;padding:24px;color:#182c40;background:#f7f9fc}}h1,h2{{line-height:1.4}}section,details{{background:white;border:1px solid #dbe4ed;border-radius:12px;padding:20px;margin:18px 0}}table{{border-collapse:collapse;width:100%;background:white}}td,th{{padding:9px;border:1px solid #dbe4ed;text-align:left}}.scroll{{overflow:auto}}img{{max-width:100%;height:auto}}pre{{white-space:pre-wrap;word-break:break-word;font:inherit}}summary{{cursor:pointer;font-weight:bold}}input{{padding:12px;width:90%}}a{{color:#075bad}}.note{{border-left:5px solid #eead35;padding:12px;background:#fff4d9}}</style><h1>광명3구역 ‘159’ 민원 분석</h1><p>수집 기준 2026-11-08 · 시장에게 바란다 · 제목+내용 ‘159’ · 날짜·부서 제한 없음</p><p><a href="../20261030-159-petitions/">2026-10-30 분석 이력 원본</a> · <a href="data.zip">분석자료 ZIP</a> · <a href="all_petitions.csv">전체 목록 CSV</a></p><section><h2>수집 범위와 변경 내역</h2>'''
body+=table(['구분','10월30일','11월8일'],[['검색 결과',94,113],['공개 본문',75,92],['비공개',19,21],['관련 공개',67,len(rel)],['무관 공개',8,92-len(rel)]])
body+=f'<p>신규 검색 노출 {len(newall)}건, 이전 접수번호 미노출 {len(missing)}건, 기존 글 답변 추가 {summary["answers_added"]}건. 비공개 글은 본문을 열지 않았습니다. 게시기간이 끝난 민원·다른 검색어·타 민원 채널은 이번 전수 범위에 포함하지 않습니다.</p></section>'
body+='''<section><h2>핵심 근거와 해석</h2><p><b>공식 답변은 2026년 10월 23일 정비사업 대책단 회의 결과를 토대로 LH가 오리로 대로변 상가 포함 여부를 검토 중이라고 설명합니다.</b> 포함·제척 확정 통지가 아닙니다.</p><p>2026-4054 및 2026-4053 글의 답변일 필드는 11월 4일, 답변 본문 서명은 11월 3일입니다. 두 날짜를 그대로 보존했습니다. 민원은 ‘159번지 일원’ 주거환경을 강조하지만 답변은 ‘오리로 대로변 상가(159번지 일원 상가동)’를 특정하므로 대상 필지가 같은지 확인해야 합니다.</p><p class=note>10월23일 회의는 7월1일 보완 요구보다 뒤입니다. 이 회의를 7월 보완 요구의 최초 원인으로 볼 수 없습니다. ‘13개 상가’, ‘20세대 미만’, ‘약200세대’, ‘70% 동의’는 민원인 주장이고 단위·모집단·검증자료가 다릅니다.</p>'''
body+=table(['확인 방향','요구할 원자료','분석 목적'],[['7월 보완 요구의 출처','7월1일 공문·붙임, 인용 민원 접수번호·일자·채널, 7월30일 LH 항목별 조치계획','민원→검토→보완 요구 연결 확인'],['10월23일 회의','회의록·참석자·안건·검토도면·전문가 의견·LH 전달문','상가 포함 여부 검토의 근거 확인'],['주거지와 상가 범위','최초·보완·최신 경계도와 대상 필지 목록','주거지 편입과 상가 포함을 동일 요구로 처리했는지 확인'],['상가 존치 대안','존치+이면 주거지 편입의 도로·소방·사업성 비교자료','대안 배제·채택 사유 확인'],['대표성','동의 기준일·대상자·면적·세대수·검증 방법','게시글 수를 주민 수나 동의율로 오해하지 않도록 구분']])+'</section>'
body+='<section><h2>단어 분석</h2><p>Kiwi 명사 NNG·NNP, 두 글자 이상, 일반어 불용어 제외. 제목·답변·댓글을 제외한 관련 민원 본문을 분석했습니다. TF는 반복 출현 수, DF는 해당 명사를 쓴 글 수입니다. 워드클라우드는 여론 비율이나 찬반 투표가 아닙니다.</p>'
for f,t in [('wordcloud_df','전체 관련 본문 · DF'),('wordcloud_tf','전체 관련 본문 · TF'),('wordcloud_new','신규 관련 본문 · DF'),('wordcloud_answer','시 답변만 별도 분석 · DF'),('token_df','상위 명사와 글 수'),('monthly','월별 관련 공개 글 수')]:body+=f'<h3>{t}</h3><img src="{f}.png" alt="{t}">'
body+=table(['주제(중복 집계)','전체 관련','신규 관련'],[[r['theme'],r['current'],r['new']] for r in counts])+f'<p>주제는 정규식 언급 분류로 찬반 입장 판정이 아닙니다. 본문 공백 제거 후 문자 유사도 0.85 이상 {len(pairs)}쌍을 별도 제공했습니다. 문장 유사성만으로 동일 작성자·조직 동원을 판단할 수 없습니다. 답변일 확인 글의 등록→답변 중앙값은 {summary["median_answer_days"]}일(달력일)입니다.</p></section>'
body+='<section><h2>히스토리로그</h2><p>2026-10-30: 당시 94건 분석 원본을 보존. 2026-11-08: 113건 검색 목록 및 공개92건 본문·답변 재수집. 기존 보고서·ZIP은 수정하지 않고 새 경로에 저장.</p><p>비교는 접수번호 기준이며 조회수·목록 순번은 변경 기준에서 제외했습니다. 새 검색 노출은 신규 접수와 동일하다고 단정하지 않습니다.</p></section>'
body+='<h2>전체 검색 목록 113건</h2>'+table(['접수번호','날짜','제목','상태','범위','변경'],[[r['number'],r['date'],r['title'],r['status'],'관련' if r['related'] else ('비공개' if not r['public'] else '무관'),r['change']] for r in records])
body+='<h2>공개 본문·답변 92건</h2><input id=q placeholder="접수번호·제목·본문 검색" oninput="document.querySelectorAll(\'details\').forEach(d=>d.hidden=!d.innerText.includes(this.value))">'
for r in records:
 if r['public']:body+=f'<details><summary>{e(r["number"])} · {e(r["date"])} · {e(r["title"])}</summary><h3>민원인 주장</h3><pre>{e(r["body"])}</pre><h3>시 답변 · {e(r["answer_date"])}</h3><pre>{e(r["answer"] or "수집 화면에 답변 없음")}</pre></details>'
body+='<p>출처: <a href="https://www.gm.go.kr/pd/minwon/BD_minwonSelectBbs.do">광명시 시장에게 바란다</a>. 접수번호로 원문 확인. 민원인의 사실 주장과 공식 답변을 구분하며 첨부파일 원본 및 댓글은 이번 분석 대상에서 제외했습니다.</p></html>'
(p/'index.html').write_text(body)
(p/'methodology.json').write_text(json.dumps({'stopwords':sorted(stop),'noun_tags':['NNG','NNP'],'minimum_length':2,'body_only':True,'themes':themes,'similarity':'difflib.SequenceMatcher autojunk=False whitespace removed >=0.85','baseline_sha256':summary['baseline_sha256']},ensure_ascii=False,indent=2))
with zipfile.ZipFile(p/'data.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in p.iterdir():
  if f.suffix in ['.json','.csv','.png','.html','.py'] and f.name!='baseline.html':z.write(f,f.name)
